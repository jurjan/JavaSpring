package com.coursework.courseprojectfxeng.model;

public enum SeedType {
    BULB, SEED, ROOT
}
