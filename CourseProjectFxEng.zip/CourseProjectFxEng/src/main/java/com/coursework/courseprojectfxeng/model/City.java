package com.coursework.courseprojectfxeng.model;

public enum City {
    KLAIPEDA, VILNIUS, KAUNAS, PANEVEZYS, SIAULIAI
}
